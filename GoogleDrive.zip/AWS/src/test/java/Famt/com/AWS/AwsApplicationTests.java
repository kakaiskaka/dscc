package Famt.com.AWS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AwsApplicationTests {

	@Test
	void contextLoads() {
	}

}
